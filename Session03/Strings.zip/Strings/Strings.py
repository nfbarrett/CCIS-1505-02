#Sample Code Using Strings

sampleString=input("Enter your first and last name in lower case: ")

print ("Raw input string is: " + sampleString)

sampleString=sampleString.upper()

print ("Input string in all uppercase is: " + sampleString)

sampleString=sampleString.lower()

print ("Input string in all lowercase is: " + sampleString)

sampleString=sampleString.title()

print ("Input string in title is: " + sampleString)


sampleString=sampleString.swapcase()

print ("Input string with swapcase is: " + sampleString)

sampleString=sampleString.capitalize()

print ("Input string capitalized is: " + sampleString)

sampleString=sampleString.replace("e", "o")

print ("Input string replacing e's with o's is: " + sampleString)
